import React, { useState, useEffect } from 'react';
import { Briefcase, Calendar, User, ExternalLink, Loader2, AlertCircle } from 'lucide-react';

const JobBoard = () => {
  const [jobs, setJobs] = useState([]);
  const [jobIds, setJobIds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(0);
  const jobsPerPage = 6;

  // Fetch job IDs on component mount
  useEffect(() => {
    fetchJobIds();
  }, []);

  const fetchJobIds = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetch('https://hacker-news.firebaseio.com/v0/jobstories.json');
      if (!response.ok) throw new Error('Failed to fetch job stories');
      const ids = await response.json();
      setJobIds(ids);
      
      // Load initial batch of jobs
      await loadJobsForPage(ids, 0);
    } catch (err) {
      setError('Failed to load job postings. Please try again later.');
      console.error('Error fetching job IDs:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadJobsForPage = async (allJobIds, pageNumber) => {
    const startIndex = pageNumber * jobsPerPage;
    const endIndex = startIndex + jobsPerPage;
    const pageJobIds = allJobIds.slice(startIndex, endIndex);

    try {
      const jobPromises = pageJobIds.map(async (id) => {
        const response = await fetch(`https://hacker-news.firebaseio.com/v0/item/${id}.json`);
        if (!response.ok) throw new Error(`Failed to fetch job ${id}`);
        return await response.json();
      });

      const pageJobs = await Promise.all(jobPromises);
      // Filter out null/deleted jobs
      const validJobs = pageJobs.filter(job => job && job.title);
      
      if (pageNumber === 0) {
        setJobs(validJobs);
      } else {
        setJobs(prev => [...prev, ...validJobs]);
      }
      
      setCurrentPage(pageNumber);
    } catch (err) {
      console.error('Error loading jobs for page:', err);
      if (pageNumber === 0) {
        setError('Failed to load job details. Please try again later.');
      }
    }
  };

  const loadMoreJobs = async () => {
    setLoadingMore(true);
    await loadJobsForPage(jobIds, currentPage + 1);
    setLoadingMore(false);
  };

  const formatDate = (timestamp) => {
    if (!timestamp) return 'Unknown date';
    const date = new Date(timestamp * 1000);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const hasMoreJobs = () => {
    return (currentPage + 1) * jobsPerPage < jobIds.length;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600 text-lg">Loading job postings...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-6">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Oops! Something went wrong</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <button 
            onClick={fetchJobIds}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center space-x-3">
            <Briefcase className="w-8 h-8 text-blue-600" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Hacker News Jobs</h1>
              <p className="text-gray-600">Latest job postings from the Hacker News community</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {jobs.length === 0 ? (
          <div className="text-center py-12">
            <Briefcase className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 text-lg">No job postings available at the moment.</p>
          </div>
        ) : (
          <>
            {/* Job Count */}
            <div className="mb-6">
              <p className="text-gray-600">
                Showing {jobs.length} of {jobIds.length} job postings
              </p>
            </div>

            {/* Jobs Grid */}
            <div className="space-y-4 mb-8">
              {jobs.map((job) => (
                <div key={job.id} className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow p-6">
                  <div className="flex flex-col space-y-3">
                    {/* Job Title */}
                    <div>
                      {job.url ? (
                        <a
                          href={job.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xl font-semibold text-blue-600 hover:text-blue-800 transition-colors inline-flex items-center gap-2 group"
                        >
                          {job.title}
                          <ExternalLink className="w-4 h-4 opacity-50 group-hover:opacity-100" />
                        </a>
                      ) : (
                        <h3 className="text-xl font-semibold text-gray-900">{job.title}</h3>
                      )}
                    </div>

                    {/* Job Meta Information */}
                    <div className="flex flex-wrap items-center gap-6 text-sm text-gray-600">
                      {job.by && (
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4" />
                          <span>Posted by {job.by}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>{formatDate(job.time)}</span>
                      </div>
                    </div>

                    {/* Job Description Preview */}
                    {job.text && (
                      <div className="text-gray-700 text-sm">
                        <div 
                          dangerouslySetInnerHTML={{ 
                            __html: job.text.length > 200 
                              ? job.text.substring(0, 200) + '...' 
                              : job.text 
                          }} 
                          className="prose prose-sm max-w-none"
                        />
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Load More Button */}
            {hasMoreJobs() && (
              <div className="text-center">
                <button
                  onClick={loadMoreJobs}
                  disabled={loadingMore}
                  className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors inline-flex items-center gap-2"
                >
                  {loadingMore ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Loading...
                    </>
                  ) : (
                    'Load More Jobs'
                  )}
                </button>
              </div>
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-4xl mx-auto px-4 py-6 text-center text-gray-600">
          <p>Data sourced from the Hacker News API</p>
        </div>
      </footer>
    </div>
  );
};

export default JobBoard;